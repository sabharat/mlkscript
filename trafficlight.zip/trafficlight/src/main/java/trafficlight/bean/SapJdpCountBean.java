package trafficlight.bean;

public class SapJdpCountBean
{
  private int sap_id;
  private int sap_count;
  private int jdp_id;
  private int jpd_count;
  private String modelname;
  private String timestamp;
  private int difference;
  
  public int getSap_id()
  {
    return this.sap_id;
  }
  
  public void setSap_id(int d)
  {
    this.sap_id = d;
  }
  
  public int getSap_count()
  {
    return this.sap_count;
  }
  
  public void setSap_count(int sap_count)
  {
    this.sap_count = sap_count;
  }
  
  public int getJdp_id()
  {
    return this.jdp_id;
  }
  
  public void setJdp_id(int jdp_id)
  {
    this.jdp_id = jdp_id;
  }
  
  public int getJpd_count()
  {
    return this.jpd_count;
  }
  
  public void setJpd_count(int jpd_count)
  {
    this.jpd_count = jpd_count;
  }
  
  public String getModelname()
  {
    return this.modelname;
  }
  
  public void setModelname(String modelname)
  {
    this.modelname = modelname;
  }
  
  public String getTimestamp()
  {
    return this.timestamp;
  }
  
  public void setTimestamp(String timestamp)
  {
    this.timestamp = timestamp;
  }
  
  public int getDifference()
  {
    return this.difference;
  }
  
  public void setDifference(int difference)
  {
    this.difference = difference;
  }
  
  public String toString()
  {
    return "SapJdpCountBean [sap_id=" + this.sap_id + ", sap_count=" + this.sap_count + ", jdp_id=" + this.jdp_id + ", jpd_count=" + this.jpd_count + ", modelname=" + this.modelname + ", timestamp=" + this.timestamp + ", difference=" + this.difference + "]";
  }
}
