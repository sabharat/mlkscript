package trafficlight.app;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Properties;

import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Multipart;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;
import javax.activation.DataHandler;
import javax.activation.DataSource;
import javax.activation.FileDataSource;
import javax.mail.BodyPart;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Multipart;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;

import org.apache.log4j.Logger;

public class EmailAttachmentSender {
	private static final Logger logger = Logger
			.getLogger(EmailAttachmentSender.class);
	private static final String HOST = "mail_host";
	private static final String PORT = "mail_port";
	private static final String TO = "mail_to";
	private static final String TOADMIN = "mail_admin";
	private static final String ATTACHMENT = "mail_attachment";
	private static final String SUBJECT = "mail_subject";
	private static final String BODY = "mail_body";

	public static void sendEmailWithAttachments(String host, String port,
			String toAddress, String subject, String message,
			String[] attachFiles) throws AddressException, MessagingException,
			UnsupportedEncodingException {

		Properties props = System.getProperties();

		props.put("mail.smtp.host", host);

		Session session = Session.getInstance(props, null);

		MimeMessage msg = new MimeMessage(session);
		// set message headers
		msg.addHeader("Content-type", "text/HTML; charset=UTF-8");
		msg.addHeader("format", "flowed");
		msg.addHeader("Content-Transfer-Encoding", "8bit");

		msg.setFrom(new InternetAddress("no_reply@elisa.fi", "NoReply-JPD"));

		//msg.setReplyTo(InternetAddress.parse("no_reply@journaldev.com", false));

		msg.setSubject(subject, "UTF-8");

		//msg.setText(message, "UTF-8");
        // creates message part
        MimeBodyPart messageBodyPart = new MimeBodyPart();
        messageBodyPart.setContent(message, "text/html");
       
        // creates multi-part
        Multipart multipart = new MimeMultipart();
        multipart.addBodyPart(messageBodyPart);

        // adds attachments
        if (attachFiles != null && attachFiles.length > 0) {
            for (String filePath : attachFiles) {
                MimeBodyPart attachPart = new MimeBodyPart();
 
                try {
                    attachPart.attachFile(filePath);
                } catch (IOException ex) {
                    ex.printStackTrace();
                }
 
                multipart.addBodyPart(attachPart);
            }
        }

        // sets the multi-part as e-mail's content
        msg.setContent(multipart);

		msg.setSentDate(new Date());

		msg.setRecipients(Message.RecipientType.TO,
				InternetAddress.parse(toAddress, false));
		logger.info("Message is ready");
		Transport.send(msg);

	}

	/**
	 * Test sending e-mail with attachments
	 * 
	 * @param totalsapcount
	 * @param totaljpdcount
	 * @param countdifference 
	 * @throws Exception 
	 */
	public boolean sendstatus(int totaljpdcount, int totalsapcount, int countdifference) throws Exception {
		boolean status = false;
		DateFormat dateFormat = new SimpleDateFormat(
				"yyyy.MM.dd 'at' HH:mm:ss z");
		Date date = new Date();
		try {
			GetPropertyValue fetchprop = App.fetchprop;
			// SMTP info
			String host = fetchprop.get(HOST);
			String port = fetchprop.get(PORT);

			// message info
			String mailTo = fetchprop.get(TO);
			String subject = fetchprop.get(SUBJECT);
			String message = fetchprop.get(BODY);
			// preparing message
			message = message.replaceAll("<JPDCount>",
					String.valueOf(totaljpdcount));
			message = message.replaceAll("<SAPCount>",
					String.valueOf(totalsapcount));
			message = message.replaceAll("<Date and Time>",
					dateFormat.format(date).toString());
			message = message.replaceAll("<CountDifference>",
					String.valueOf(countdifference));
			message = message.replaceAll("<n>",
					String.valueOf("<br/>"));
			// attachments
			String[] attachFiles = new String[1];
			attachFiles[0] = fetchprop.get(ATTACHMENT);

			sendEmailWithAttachments(host, port, mailTo, subject, message,
					attachFiles);
			logger.info("Email sent.");
			status = true;

		} catch (Exception e) {
			logger.info("Could not send email.");
			logger.error(e.getMessage());
			throw e;
		}
		return status;
	}

	public void senderrormail(String body) throws Exception {
		GetPropertyValue fetchprop = App.fetchprop;
		// SMTP info
		String host = fetchprop.get(HOST);
		String port = fetchprop.get(PORT);

		// message info
		String mailTo = fetchprop.get(TOADMIN);
		String subject = "ERROR IN Traffic lights automation application";
		String message = body;
		logger.info("Sending error mail with message::"+message);
		

		Properties props = System.getProperties();

		props.put("mail.smtp.host", host);

		Session session = Session.getInstance(props, null);

		MimeMessage msg = new MimeMessage(session);
		// set message headers
		msg.addHeader("Content-type", "text/HTML; charset=UTF-8");
		msg.addHeader("format", "flowed");
		msg.addHeader("Content-Transfer-Encoding", "8bit");

		msg.setFrom(new InternetAddress("no_reply@elisa.fi", "NoReply-JPD"));

		//msg.setReplyTo(InternetAddress.parse("no_reply@journaldev.com", false));

		msg.setSubject(subject, "UTF-8");

		//msg.setText(message, "UTF-8");
        // creates message part
        MimeBodyPart messageBodyPart = new MimeBodyPart();
        messageBodyPart.setContent(message, "text/html");
 
        // creates multi-part
        Multipart multipart = new MimeMultipart();
        multipart.addBodyPart(messageBodyPart);
        msg.setContent(multipart);

		msg.setSentDate(new Date());

		msg.setRecipients(Message.RecipientType.TO,
				InternetAddress.parse(mailTo, false));
		logger.info("Message is ready");
		Transport.send(msg);
		
	}
}