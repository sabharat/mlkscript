package trafficlight.app;

import java.io.File;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.log4j.Logger;

public class FileArchive {
	//private static final String SAP_EXCEL_LOCATION = "sap_excel_location";
	private static final String JPD_EXCEL_LOCATION = "jpd_excel_location";
	//private static final String SAP_ARCHIVE_LOCATION = "sap_archive_folder";
	private static final String JPD_ARCHIVE_LOCATION = "jpd_archive_folder";

	private static final Logger logger = Logger.getLogger(FileArchive.class);

	public void archivefiles() throws Exception {
		DateFormat dateFormat = new SimpleDateFormat("yyyyMMddhhmm'.xlsx'");
		Date date = new Date();
		GetPropertyValue fetchprop = App.fetchprop;
	/*	// moving SAP file to archive
		File f = new File(fetchprop.get(SAP_EXCEL_LOCATION));
		File fnew = new File(fetchprop.get(SAP_ARCHIVE_LOCATION)
				+ dateFormat.format(date).toString());
		if (f.renameTo(fnew)) {
			logger.info("SAP File rename success to ::"
					+ fetchprop.get(SAP_ARCHIVE_LOCATION)
					+ dateFormat.format(date).toString());
			;
		} else {
			logger.error("SAP File rename failed");
		}
		*/
		// moving JPD file to archive
		File result = new File(fetchprop.get(JPD_EXCEL_LOCATION));
		File resultnew = new File(fetchprop.get(JPD_ARCHIVE_LOCATION)
				+ dateFormat.format(date).toString());
		if (result.renameTo(resultnew)) {
			logger.info("JPD File rename success to ::"
					+ fetchprop.get(JPD_ARCHIVE_LOCATION)
					+ dateFormat.format(date).toString());
			;
		} else {
			logger.error("JPD File rename failed");
		}

	}

}
