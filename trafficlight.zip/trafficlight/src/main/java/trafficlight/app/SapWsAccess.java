package trafficlight.app;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.util.ArrayList;

import javax.xml.soap.MessageFactory;
import javax.xml.soap.SOAPBody;
import javax.xml.soap.SOAPConnection;
import javax.xml.soap.SOAPConnectionFactory;
import javax.xml.soap.SOAPException;
import javax.xml.soap.SOAPMessage;
import javax.xml.transform.Source;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.stream.StreamResult;

import org.apache.log4j.Logger;
import org.w3c.dom.NodeList;

import trafficlight.bean.SapJdpCountBean;

public class SapWsAccess {
	GetPropertyValue fetchprop = App.fetchprop;
	private static final Logger logger = Logger.getLogger(SapWsAccess.class);
	private static final String SAP_WS_URL = "sap_url";
	private static final String SAP_REQUEST = "sap_request";

	public ArrayList<SapJdpCountBean> getSapList(
			ArrayList<SapJdpCountBean> countlist) throws Exception {
		// Create SOAP Connection
		SOAPConnectionFactory soapConnectionFactory = SOAPConnectionFactory
				.newInstance();
		SOAPConnection soapConnection = soapConnectionFactory
				.createConnection();
		
		// Send SOAP Message to SOAP Server
		String url = fetchprop.get(SAP_WS_URL);
		SOAPMessage soapResponse = soapConnection.call(getSOAPRequest(),
				url);

		// Process the SOAP Response
		countlist=parseSOAPResponse(soapResponse,countlist);

		soapConnection.close();
		

		return countlist;
		// TODO Auto-generated method stub

	}
	
	private ArrayList<SapJdpCountBean> parseSOAPResponse(
			SOAPMessage soapResponse, ArrayList<SapJdpCountBean> countlist) throws Exception {

		TransformerFactory transformerFactory = TransformerFactory
				.newInstance();
		Transformer transformer = transformerFactory.newTransformer();
		Source sourceContent = soapResponse.getSOAPPart().getContent();
		logger.info("\nResponse SOAP Message = ");
		StreamResult result = new StreamResult(System.out);
		transformer.transform(sourceContent, result);
		logger.info("/n Parsing request output into an object list");

		SOAPBody sb = soapResponse.getSOAPBody();
		NodeList sapid = sb.getElementsByTagName("MATNR");
		NodeList productname = sb.getElementsByTagName("MAKTX");
		NodeList count = sb.getElementsByTagName("SAPCOUNT");

		if (sapid.getLength() == productname.getLength()
				&& productname.getLength() == count.getLength()) {
			logger.info("Number of products fetched::"
					+ sapid.getLength());
			for (int i = 0; i < sapid.getLength(); i++) {
				logger.info(i);
				SapJdpCountBean sapjpdcount = new SapJdpCountBean();
				if (sapid.item(i).getTextContent() != null
						&& !sapid.item(i).getTextContent().isEmpty()
						&& productname.item(i).getTextContent() != null
						&& !productname.item(i).getTextContent().isEmpty()
						&& count.item(i).getTextContent() != null
						&& !count.item(i).getTextContent().isEmpty()) {
					sapjpdcount.setSap_id(Integer.parseInt(sapid.item(i)
							.getTextContent()));
					sapjpdcount.setModelname(productname.item(i)
							.getTextContent());
					sapjpdcount.setSap_count((int) Double.parseDouble(count
							.item(i).getTextContent()));
					logger.info(sapjpdcount.toString());
					countlist.add(sapjpdcount);
				} else {
					logger.error("Invalid Sap Response::null in node::"
							+ i);
				}
			}
		} else {
			throw new Exception(
					"Invalid Sap Response:: number of nodes unequal");
		}

	
		
		
		return countlist;
	}

	private  SOAPMessage getSOAPRequest() throws Exception {
	/*	String send = "<Envelope xmlns=\"http://schemas.xmlsoap.org/soap/envelope/\">"
				+ " <Body>"
				+ " <ZFM_MM_JPD_RESERVATION_CNT xmlns=\"urn:sap-com:document:sap:rfc:functions\">"
				+ "     <RESERVATIONS xmlns=\"\">"
				+ "    </RESERVATIONS>"
				+ "   </ZFM_MM_JPD_RESERVATION_CNT>"
				+ " </Body>"
				+ "</Envelope>"; */
		
		String send = fetchprop.get(SAP_REQUEST);

		InputStream is = new ByteArrayInputStream(send.getBytes());
		SOAPMessage request = MessageFactory.newInstance().createMessage(null,
				is);

		return request;

	}

}
