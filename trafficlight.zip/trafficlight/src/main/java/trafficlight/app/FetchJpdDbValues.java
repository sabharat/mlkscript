package trafficlight.app;

import java.io.IOException;
import java.sql.DriverManager;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import org.apache.log4j.Logger;

import trafficlight.bean.SapJdpCountBean;

public class FetchJpdDbValues {

	private static final String DB_DRIVER = "driver";
	private static final String DB_CONNECTION = "url";
	private static final String DB_USER = "user";
	private static final String DB_PASSWORD = "password";
	public static Connection dbConnection = null;
	private DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
	private Date date = new Date();
	private static final Logger logger = Logger
			.getLogger(FetchJpdDbValues.class);

	public ArrayList<SapJdpCountBean> populatevalues(
			ArrayList<SapJdpCountBean> countlist) throws Exception {
		dbConnection = getDBConnection();
		for (SapJdpCountBean sjcb : countlist) {

			try {
				sjcb = selectRecordsFromTable(sjcb);
				sjcb.setTimestamp(dateFormat.format(date));
				sjcb.setDifference(sjcb.getSap_count() - sjcb.getJpd_count());
			} catch (SQLException e) {
				logger.error(e.getMessage());
				throw e;

			}
		}
		if (dbConnection != null) {
			dbConnection.close();
		}
		return countlist;

	}

	private static SapJdpCountBean selectRecordsFromTable(SapJdpCountBean sjcb)
			throws SQLException, IOException {

		PreparedStatement preparedStatement = null;

		String selectSQL = "select ho.handsetmodel,si.name,count(distinct sr.sap_order_id)"
				+ " from handsetorder ho, product_order_item poi, shopreclaimorder so, sap_reservation sr, stock_item si"
				+ " where ho.status = 'new' and ho.credit_status = 'checked_ok' and ho.aindex = poi.order_id "
				+ " and poi.order_type = 'handset' and so.product_order_group_id = poi.group_id and si.handsetmodel_id=ho.handsetmodel"
				+ " and so.sap_reservation_id = sr.aindex and so.status = 'wait_shop_reclaim' and si.sap_material_id=?"
				+ " and sr.status = 'reserved_with_order' "
				+ " group by ho.handsetmodel";

		try {

			preparedStatement = dbConnection.prepareStatement(selectSQL);
			preparedStatement.setInt(1, sjcb.getSap_id());

			// execute select SQL stetement
			ResultSet rs = preparedStatement.executeQuery();

			while (rs.next()) {

				String handsetmodel = rs.getString("handsetmodel");
				String name = rs.getString("name");
				String count = rs.getString("count(distinct sr.sap_order_id)");
				logger.info("Values fetched from JPD DB Jpd ID::"
						+ handsetmodel + "  name::" + name + "   count::"
						+ count);

				// setting values in to bean
				sjcb.setJdp_id(Integer.parseInt(handsetmodel));
				// sjcb.setModelname(name);
				sjcb.setJpd_count(Integer.parseInt(count));
			}

		} catch (SQLException e) {

			logger.error(e.getMessage());

		} finally {

			if (preparedStatement != null) {
				preparedStatement.close();
			}

		}
		return sjcb;

	}

	private static Connection getDBConnection() throws Exception {

		Connection dbConnection = null;
		GetPropertyValue fetchprop = App.fetchprop;

		try {

			Class.forName(fetchprop.get(DB_DRIVER));

		} catch (ClassNotFoundException e) {

			logger.error(e.getMessage());
			throw e;

		}

		try {

			dbConnection = DriverManager.getConnection(
					fetchprop.get(DB_CONNECTION), fetchprop.get(DB_USER),
					fetchprop.get(DB_PASSWORD));
			return dbConnection;

		} catch (Exception e) {
			logger.error(e.getMessage());
			throw e;
		} 

	}
	

}
