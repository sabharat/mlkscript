package trafficlight.app;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Date;
import java.util.Properties;

import org.apache.log4j.Logger;

public class GetPropertyValue {
	String result = "";
	InputStream inputStream;
	private static final Logger logger = Logger
			.getLogger(GetPropertyValue.class);
	Properties prop = new Properties();

	public GetPropertyValue(Properties myProps) {
		prop=myProps;
	}

	public  String get(String propertyname) throws Exception {

		try {
			/*Properties prop = new Properties();
		     String propFileName = "app.properties";
			System.out.println(new File(propFileName).getAbsolutePath());

			inputStream = getClass().getClassLoader().getResourceAsStream(
					propFileName);

			if (inputStream != null) {
				prop.load(inputStream);
			} else {
				throw new FileNotFoundException("property file '"
						+ propFileName + "' not found in the classpath");
			}

			// get the property value and print it out*/
			result = prop.getProperty(propertyname); 
			logger.info("Propertyname :: " + propertyname+ "Value:: "+ result);

		} catch (Exception e) {
			logger.error("Exception: " + e);
			throw e;
		} finally {
			//inputStream.close();
		}
		return result;
	}

	

}
