package trafficlight.app;

import java.io.FileInputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Properties;

import org.apache.log4j.Logger;

import trafficlight.bean.SapJdpCountBean;

public class App {
	private static final String SAP_WS_URL = "sap_url";
	private static boolean MAIL_SENT = false;
	private static final String SENDMAIL = "send_mail";
	private static final String COUNTDIFFERENCEALLOWED = "count_difference_allowed";
	private static final Logger logger = Logger.getLogger(App.class);
	public static ArrayList<SapJdpCountBean> countlist = new ArrayList<SapJdpCountBean>();
	private static int totaljpdcount = 0;
	private static int totalsapcount = 0;
	public static GetPropertyValue fetchprop;
	public static int countdifference;

	public static void main(String[] args) throws Exception {
		EmailAttachmentSender statusmailsender = new EmailAttachmentSender();
		try {
			String propPath = System.getProperty("myPropertiesFile");
			if (propPath != null) {
				FileInputStream in = new FileInputStream(propPath);
				try {
					Properties myProps = new Properties();
					myProps.load(in);
					fetchprop = new GetPropertyValue(myProps);
				} finally {
					in.close();
				}
			} else {
				throw new Exception("Properties file not found");
			}
			logger.info("TrafficLight report application start");

			FileArchive filearchive = new FileArchive();
			SapWsAccess sapws = new SapWsAccess();
			countlist = sapws.getSapList(countlist);
			if ((!countlist.isEmpty()) && (countlist.size() != 0)) {
				logger.info("Number ofrecords fetched from SAP webservice ::"
						+ countlist.size());

				FetchJpdDbValues fetchjpd = new FetchJpdDbValues();
				countlist = fetchjpd.populatevalues(countlist);
				Collections.sort(countlist, new Comparator <SapJdpCountBean>() {
					public int compare(SapJdpCountBean o1, SapJdpCountBean o2) {
						return o1.getDifference() - o2.getDifference();
					}
				});
				for (SapJdpCountBean SapJdpCountBean : countlist) {
					logger.info(SapJdpCountBean.toString());

					totaljpdcount = totaljpdcount
							+ SapJdpCountBean.getJpd_count();

					totalsapcount = totalsapcount
							+ SapJdpCountBean.getSap_count();

					countdifference = countdifference
							+ Math.abs(SapJdpCountBean.getDifference());
				}
				logger.info("totaljpdcount::" + totaljpdcount
						+ "  totalsapcount::" + totalsapcount);

				int percentagedifferenceincount = countdifference * 100
						/ totalsapcount;
				if (Integer.parseInt(fetchprop.get("count_difference_allowed")) < percentagedifferenceincount) {
					throw new Exception("COUNT DIFFERENCE PERCENTAGE IS "
							+ percentagedifferenceincount);
				}
				ExcelWriter writer = new ExcelWriter();
				writer.write(countlist, totaljpdcount, totalsapcount,
						countdifference);
				if (fetchprop.get("send_mail").equalsIgnoreCase("TRUE")) {
					logger.info("Sending status mail");
					MAIL_SENT = statusmailsender.sendstatus(totaljpdcount,
							totalsapcount, countdifference);
				}
				if (MAIL_SENT) {
					filearchive.archivefiles();
				}
			} else {
				logger.info("No sap records fetched from WS::"
						+ fetchprop.get("sap_url"));
			}
			logger.info("TrafficLight report application Complete");
		} catch (Exception e) {
			logger.error("ERROR::" + e.getMessage());

			statusmailsender.senderrormail(e.getMessage());
		}
	}
}
