package trafficlight.app;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;

import org.apache.log4j.Logger;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import trafficlight.bean.SapJdpCountBean;

public class ReadExcel {

	private static final Logger logger = Logger.getLogger(ReadExcel.class);

	public ArrayList<SapJdpCountBean> extractValues(
			ArrayList<SapJdpCountBean> countlist, FileInputStream inputStream) throws Exception {
		Workbook workbook;
		try {
			workbook = new XSSFWorkbook(inputStream);

			Sheet firstSheet = workbook.getSheetAt(0);
			Iterator<Row> iterator = firstSheet.iterator();

			while (iterator.hasNext()) {
				// incrementing rows
				Row nextRow = iterator.next();

				Iterator<Cell> cellIterator = nextRow.cellIterator();
				SapJdpCountBean sjcb = new SapJdpCountBean();

				// incrementing cells
				Cell cell = cellIterator.next();

                switch (cell.getCellType()) {
                case Cell.CELL_TYPE_STRING:
                    //fetching value of SAP ID
                    sjcb.setSap_id(Integer.parseInt(cell.getStringCellValue()));
                    cell = cellIterator.next();
                  //fetching value of product name
                    sjcb.setModelname(cell.getStringCellValue());
                    cell = cellIterator.next();
                    //fetching sap count
                    sjcb.setSap_count((int)cell.getNumericCellValue());
                    if(sjcb.getSap_id()!=0)
                    countlist.add(sjcb);
                    break;
                case Cell.CELL_TYPE_NUMERIC:
                    //fetching value of SAP ID
                    sjcb.setSap_id((int)cell.getNumericCellValue());
                    cell = cellIterator.next();
                  //fetching value of product name
                    sjcb.setModelname(cell.getStringCellValue());
                    cell = cellIterator.next();
                    //fetching sap count
                    sjcb.setSap_count((int)cell.getNumericCellValue());
                    if(sjcb.getSap_id()!=0)
                    countlist.add(sjcb);
                    break;
            }

			}
			

			workbook.close();
			inputStream.close();
		} catch (Exception e) {
			logger.equals(e.getMessage());
			throw e;
		}

		return countlist;

	}

}
