package trafficlight.app;

import java.io.FileOutputStream;
import java.util.ArrayList;
import org.apache.log4j.Logger;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import trafficlight.bean.SapJdpCountBean;

public class ExcelWriter
{
  private static final Logger logger = Logger.getLogger(ExcelWriter.class);
  private static final String JPD_SAP_COUNT_EXCEL_NAME = "jpd_excel_location";
  
  public void write(ArrayList<SapJdpCountBean> countlist, int totaljpdcount, int totalsapcount, int countdifference)
    throws Exception
  {
    logger.info("Started writing in excel");
    GetPropertyValue fetchprop = App.fetchprop;
    XSSFWorkbook workbook = new XSSFWorkbook();
    XSSFSheet sheet = workbook.createSheet("SAP_JPD_COUNT Status");
    
    int rowCount = 0;
    Row row0 = sheet.createRow(rowCount);
    Cell cell0 = row0.createCell(0);
    cell0.setCellValue("S.No");
    Cell cell1 = row0.createCell(1);
    cell1.setCellValue("PRODUCT");
    Cell cell2 = row0.createCell(2);
    cell2.setCellValue("DESCRIPTION");
    Cell cell3 = row0.createCell(3);
    cell3.setCellValue("SAP_COUNT");
    Cell cell4 = row0.createCell(4);
    cell4.setCellValue("JPD_COUNT");
    Cell cell5 = row0.createCell(5);
    cell5.setCellValue("COUNT_DIFFERENCE");
    for (SapJdpCountBean sjcb : countlist)
    {
      Row row = sheet.createRow(++rowCount);
      
      int columnCount = 0;
      Cell cell01 = row.createCell(columnCount);
      cell01.setCellValue(Integer.valueOf(rowCount).intValue());
      Cell cell02 = row.createCell(++columnCount);
      cell02.setCellValue(Integer.valueOf(sjcb.getSap_id()).intValue());
      Cell cell03 = row.createCell(++columnCount);
      cell03.setCellValue(sjcb.getModelname());
      Cell cell04 = row.createCell(++columnCount);
      cell04.setCellValue(Integer.valueOf(sjcb.getSap_count()).intValue());
      Cell cell05 = row.createCell(++columnCount);
      cell05.setCellValue(Integer.valueOf(sjcb.getJpd_count()).intValue());
      Cell cell06 = row.createCell(++columnCount);
      cell06.setCellValue(Integer.valueOf(sjcb.getDifference()).intValue());
    }
    Object row = sheet.createRow(++rowCount);
    int columnCount = 2;
    Cell cell001 = ((Row)row).createCell(columnCount);
    cell001.setCellValue("Total");
    Cell cell002 = ((Row)row).createCell(++columnCount);
    cell002.setCellValue(Integer.valueOf(totalsapcount).intValue());
    Cell cell003 = ((Row)row).createCell(++columnCount);
    cell003.setCellValue(Integer.valueOf(totaljpdcount).intValue());
    Cell cell004 = ((Row)row).createCell(++columnCount);
    cell004.setCellValue(Integer.valueOf(countdifference).intValue());
    
    sheet.autoSizeColumn(0);
    sheet.autoSizeColumn(1);
    sheet.autoSizeColumn(2);
    sheet.autoSizeColumn(3);
    sheet.autoSizeColumn(4);
    sheet.autoSizeColumn(5);
    
    try (FileOutputStream outputStream = new FileOutputStream(
			fetchprop.get(JPD_SAP_COUNT_EXCEL_NAME))) {
		workbook.write(outputStream);
    }

  }
}
